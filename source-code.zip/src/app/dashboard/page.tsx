import { DashboardStats } from "@/components/dashboard-stats";
import { GoalsOverview } from "@/components/goals-overview";
import { SpendingChart } from "@/components/spending-chart";
import { TransactionsList } from "@/components/transactions-list";
import { BudgetsList } from "@/components/budgets-list";
import { GoalsList } from "@/components/goals-list";
import { CategoryBreakdown } from "@/components/category-breakdown";
import { SpendingTrends } from "@/components/spending-trends";
import { FinancialSummary } from "@/components/financial-summary";
import { ReportButton } from "@/components/report-button";
import { auth } from "@/lib/auth";
import { headers } from "next/headers";
import { redirect } from "next/navigation";

export default async function DashboardPage() {
  const session = await auth.api.getSession({
    headers: await headers(),
  });

  if (!session?.user) {
    redirect("/");
  }

  return (
    <div className="min-h-screen bg-linear-to-br from-background via-background to-muted/20">
      <div className="container mx-auto p-6 space-y-8">
        <div className="flex justify-between items-center">
          <h1 className="text-3xl font-bold">Dashboard</h1>
          <ReportButton />
        </div>

        <DashboardStats />

        {/* Transactions */}
        <TransactionsList />

        {/* Alerts Panel */}
        {/* <AlertsPanel /> */}

        {/* Charts and Overview */}
        <div className="grid gap-6 lg:grid-cols-2">
          <SpendingChart />
          <GoalsOverview />
        </div>

        {/* Financial Summary & Analytics */}
        <FinancialSummary />

        {/* Reports */}
        <div className="grid gap-6 lg:grid-cols-2">
          <CategoryBreakdown />
          <SpendingTrends />
        </div>

        {/* Budgets and Goals Management */}
        <div className="grid gap-6 lg:grid-cols-2">
          <BudgetsList />
          <GoalsList />
        </div>

        {/* Recent Transactions */}
        {/* <RecentTransactions /> */}
      </div>
    </div>
  );
}
